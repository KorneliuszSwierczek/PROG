﻿namespace Calculator.Models
{
    public class Calc
    {
        public int firstNumber { get; set; }
        public int secondNumber { get; set ; }
        public string sign { get; set; }
            
    }
}
